            <div id="header">
                <h1>Creating a CAPTCHA</h1>
            </div>